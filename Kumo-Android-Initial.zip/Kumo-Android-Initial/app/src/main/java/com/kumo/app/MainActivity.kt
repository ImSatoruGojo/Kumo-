package com.kumo.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kumo.app.ui.theme.KumoTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KumoTheme { KumoApp() } }
    }
}

private enum class Tab { HOME, SEARCH, LIBRARY, SETTINGS }

@Composable
fun KumoApp() {
    var tab by remember { mutableStateOf(Tab.HOME) }
    Scaffold(
        containerColor = Color.Black,
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF101010)) {
                listOf(
                    Tab.HOME to Icons.Default.Home,
                    Tab.SEARCH to Icons.Default.Search,
                    Tab.LIBRARY to Icons.Default.VideoLibrary,
                    Tab.SETTINGS to Icons.Default.Settings
                ).forEach { (item, icon) ->
                    NavigationBarItem(
                        selected = tab == item,
                        onClick = { tab = item },
                        icon = { Icon(icon, item.name) },
                        label = { Text(item.name.lowercase().replaceFirstChar { it.uppercase() }) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = Color.White,
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray,
                            indicatorColor = Color(0xFF2A2A2A)
                        )
                    )
                }
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding).background(Color.Black)) {
            when (tab) {
                Tab.HOME -> HomeScreen()
                Tab.SEARCH -> SearchScreen()
                Tab.LIBRARY -> PlaceholderScreen("Your Library")
                Tab.SETTINGS -> SettingsScreen()
            }
        }
    }
}

@Composable
private fun Header() {
    Column(Modifier.padding(20.dp)) {
        Text("Kumo", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Surface(color = Color(0xFFFFC107), shape = MaterialTheme.shapes.small) {
            Text("Kumo is still in beta — expect some bugs", modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), color = Color.Black, fontSize = 11.sp)
        }
    }
}

@Composable
private fun HomeScreen() {
    val categories = listOf("Anime", "Movies", "TV Shows", "Cartoons", "Manga")
    Column(Modifier.fillMaxSize()) {
        Header()
        categories.forEach { category ->
            Text(category, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
            LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items((1..6).toList()) { index ->
                    Surface(color = Color(0xFF1A1A1A), modifier = Modifier.size(width = 110.dp, height = 150.dp)) {
                        Box(contentAlignment = Alignment.Center) { Text("$category\n$index", color = Color.Gray) }
                    }
                }
            }
        }
    }
}

@Composable
private fun SearchScreen() {
    var query by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Search", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Search anime, movies, shows, manga") })
        if (query.isNotBlank()) {
            Spacer(Modifier.height(20.dp))
            listOf("Anime", "Movies", "TV Shows", "Cartoons", "Manga").forEach { type ->
                Text(type, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 8.dp))
                Text("Smart unified search results will appear here", color = Color.Gray)
            }
        }
    }
}

@Composable
private fun SettingsScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Settings", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        listOf("Anime language preference", "Movie language preference", "Default quality", "Autoplay", "Skip opening", "Double-tap seek", "Extensions & Providers", "Theme").forEach {
            Surface(color = Color(0xFF151515), modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Text(it, color = Color.White, modifier = Modifier.padding(18.dp))
            }
        }
    }
}

@Composable
private fun PlaceholderScreen(title: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(title, color = Color.White, fontSize = 24.sp) }
}

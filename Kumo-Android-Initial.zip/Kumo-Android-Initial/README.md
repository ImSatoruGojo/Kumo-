# Kumo Android Initial Build

Native Android foundation for Kumo using Kotlin, Jetpack Compose and AndroidX Media3.

Current screens:
- Home
- Search
- Library placeholder
- Settings

This is the starting point for the real APK project. Provider extensions and streaming are not implemented yet.

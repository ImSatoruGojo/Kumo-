# Kumo Copilot Handoff

Open `KUMO_COPILOT_HANDOFF.md` and give its instructions to GitHub Copilot Chat.

This archive is a complete technical handoff and development roadmap for rebuilding Kumo as a native Android application.
